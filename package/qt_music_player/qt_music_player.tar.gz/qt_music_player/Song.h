#ifndef SONG_H
#define SONG_H
#include <QString>
#include <QUrl>
#include <QList>
#include <QTableWidget>
#include <QTableWidgetItem>
class Song {
public:
    Song() = default;
    Song(QString songName, QString artistName, QUrl url, unsigned int id);
    Song(QUrl url);
    QString songName;
    QString artistName;
    QUrl url;
    unsigned int id;
    QString lyric;
    void appendToTable(QTableWidget *tb);
};
QDataStream &operator<<(QDataStream &out, const Song &s);
QDataStream &operator>>(QDataStream &in,  Song &s);
class SongList : public QList<Song> {
public :
    void wirteToTable(QTableWidget *tb);
    void appendToTable(QTableWidget *tb);
};

#endif // SONG_H
