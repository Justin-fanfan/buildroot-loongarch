QT       += core gui
QT += multimedia network
greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++11

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    Song.cpp \
    login.cpp \
    lyricdisplay.cpp \
    main.cpp \
    mainwidget.cpp \
    musiclist.cpp \
    network.cpp \
    playlist.cpp \
    songtable.cpp \
    subwindow.cpp

HEADERS += \
    Song.h \
    login.h \
    lyricdisplay.h \
    mainwidget.h \
    musiclist.h \
    network.h \
    playlist.h \
    songtable.h \
    subwindow.h

FORMS += \
    login.ui \
    mainwidget.ui \
    musiclist.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

RESOURCES += \
    pic.qrc
