#include "subwindow.h"
#include <QPainter>
#include <QVBoxLayout>
#include <QPushButton>
#include <QHBoxLayout>
#include <QSpacerItem>
#include <QMouseEvent>

SubWindow::SubWindow(QWidget *parent) : QWidget(parent)
{
    this->setStyleSheet(R"--(
SubWindow{background-color:rgba(140, 167, 255,0);border-top-left-radius:15px;border-top-right-radius:5px;})--");
    closeButton = new QPushButton(this);
    closeButton->setGeometry(this->width() - 7 - 33,4,33,27);
    this->setWindowFlag(Qt::WindowType::FramelessWindowHint);
    this->setAttribute(Qt::WA_TranslucentBackground);
    closeButton->setStyleSheet(R"--(
QPushButton{
        border-style: solid;
        border-color: #a8dadc;
        border-width: 1px;
        border-radius: 5px;
        color: rgb(0,0,0);
        padding: 2px;
        background-color: #a8dadc;
}
QPushButton::default{
        border-style: solid;
        border-color: #050a0e;
        border-width: 1px;
        border-radius: 5px;
        color: #FFFFFF;
        padding: 2px;
        background-color: #151a1e;;
}
QPushButton:hover{
        border-style: solid;
        border-color: #050a0e;
        border-width: 1px;
        border-radius: 5px;
        color: #d3dae3;
        padding: 2px;
        background-color: #1c1f1f;
}
QPushButton:pressed{
        border-style: solid;
        border-color: #050a0e;
        border-width: 1px;
        border-radius: 5px;
        color: #d3dae3;
        padding: 2px;
        background-color: #2c2f2f;
}
)--");
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/pic/win_close.png"), QSize(), QIcon::Normal, QIcon::Off);
        closeButton->setIcon(icon2);
        connect(closeButton, &QPushButton::clicked, this, &QWidget::close);
        this->resize(200,400);
}

void SubWindow::paintEvent(QPaintEvent *event)
{
    closeButton->setGeometry(this->width() - 7 - 33,4,33,27);
     QPainter painter(this);
    painter.setBrush(QBrush(QColor(140,167,255,100)));
    QPen pen(Qt::white, 4);
    painter.setPen(pen);
    QRect rect = this->rect();
    rect.setWidth(rect.width());
    rect.setHeight(rect.height());
    painter.drawRect(rect);
}

static QPoint  movePoint;
void SubWindow::mousePressEvent(QMouseEvent *event)
{
    movePoint = event->globalPos() - this->pos();

}

void SubWindow::mouseMoveEvent(QMouseEvent *event)
{
        this->move(event->globalPos() - movePoint);
}
