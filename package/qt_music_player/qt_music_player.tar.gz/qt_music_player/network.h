#ifndef NETWORK_H
#define NETWORK_H

#include <QObject>
#include <QtNetwork>
#include "Song.h"
class NetPlayList {
public:
    QString name;
    unsigned id;
};
class Network;
class SongUrlProcess  : public QObject{
    Q_OBJECT
public :
    SongUrlProcess(QNetworkAccessManager *manager, QUrl baseUrl);
    void sendRequest(Song song);
    void conn();
friend Network;
private:
    Song m_song;
    QNetworkAccessManager *manager;
    QNetworkReply *getSongUrlReply;
    QUrl baseUrl;
private slots:
    void getSongUrlSlot();
signals:
    void getSongUrlDone(Song song);


};

class Network :public QObject
{
    Q_OBJECT
private:
    QNetworkAccessManager manager;
    QUrl baseUrl;
public:
    Network(const QUrl &baseUrl);
    void search(QString keywords, int limit = 30, int offset = 0);
    void getSongUrl(Song song);
    void getLyric(unsigned id);
    void getPlayList();
    void getPlayListById(unsigned id);
    void logout();
    SongUrlProcess songUrlProcess;
    unsigned userId;
    QString nickname;
public slots:
    void login(QString user, QString password);
private :
    QNetworkReply *searchReply, *getLyricReply, *loginReply, *playListReply, *playListByIdReply, *logoutReply;
    QString cookie;
private slots:
    void processSearch(QNetworkReply *);
    void searchreadyReadSlot();
    void loginReplySlot();
    void getLyricReadyReadSlot();
    void playListReadyReadSlot();
    void playListByIdReadyReadSlot();
    void logoutReadyReadSlot();
signals :
    void searchDone(SongList);
    void getLyricDone(QString lyric);
    void loginResult(bool);
    void getPlayListDone(QList<NetPlayList>);
    void getPlayListByIdDone(SongList);
    void logoutSignal(bool);
};

#endif // NETWORK_H
