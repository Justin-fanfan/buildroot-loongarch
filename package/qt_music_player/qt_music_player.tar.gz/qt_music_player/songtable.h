#ifndef SONGTABLE_H
#define SONGTABLE_H

#include <QTableWidget>

class SongTable : public QTableWidget
{
    Q_OBJECT
public:
    SongTable(QWidget *parent = nullptr);
};

#endif // SONGTABLE_H
