#ifndef PLAYLIST_H
#define PLAYLIST_H

#include <QMediaPlaylist>
#include "Song.h"
#include <QTableWidget>

class PlayList : public QMediaPlaylist
{
    Q_OBJECT
public:
    explicit PlayList(QTableWidget *tb, QObject *parent = nullptr);
    void append(Song song);
    void appendAndPlay(Song song);
    void appendSongList(const SongList &list);
    void deleteByIndex(int n);
    void clearList();
    void loadList(const SongList &list);
    void saveInFile(QString path);
    Song &getSongById(unsigned int id);
    Song &getSongByIndex(int n);
    Song &getCurrentSong();
private:
    SongList songList;
    QTableWidget *tb;
signals :
    void wantPlay();
};

#endif // PLAYLIST_H
