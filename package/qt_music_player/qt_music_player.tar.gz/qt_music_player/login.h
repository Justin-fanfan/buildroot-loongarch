#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include "subwindow.h"

namespace Ui {
class login;
}

class login : public SubWindow
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();

public slots:
    void loginResult(bool state);

private slots:
    void on_loginButton_clicked();

    void on_logoutButton_clicked();

private:
    Ui::login *ui;
signals:
    void loginSignal(QString phone, QString passowrd);
    void logoutSignal();
};

#endif // LOGIN_H
