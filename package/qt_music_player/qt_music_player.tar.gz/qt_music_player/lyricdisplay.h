#ifndef LYRICDISPLAY_H
#define LYRICDISPLAY_H

#include <QScrollArea>
#include <QObject>
#include <QLabel>
#include <QVBoxLayout>


class LyricLine {
public:
    int milisec;
    QString line;
};

using Lyric = QVector<LyricLine>;

class LyricDisplay : public QScrollArea
{
    Q_OBJECT
public:
    LyricDisplay(QWidget *parent);
    bool setLyric(const QString &rawLyric);
    void showGeometry();
private:
    Lyric lyric;
    QVector<QLabel*> labelVector;
    QFrame *widget;
    QVBoxLayout *layout;
    QWidget *scrollContent;
    void clearLabels();
    void goToLine(int n);
    int currentLine;
public slots:
    void setPosition(int time);
protected:
    void resizeEvent(QResizeEvent *ev);

};

#endif // LYRICDISPLAY_H
