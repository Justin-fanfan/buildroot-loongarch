#include "login.h"
#include "ui_login.h"

login::login(QWidget *parent) :
    SubWindow(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
    ui->loginStateLabel->clear();
    ui->stackedWidget->setCurrentIndex(0);
    setStyleSheet(R"--(
QLabel {
        color: #d3dae3;
}
QPushButton{
        border-style: solid;
        border-color: #a8dadc;
        border-width: 1px;
        border-radius: 5px;
        color:  #d3dae3;
        padding: 2px;
        background-color: rgba(168, 218, 220,50)
}


QPushButton:hover{
        border-style: solid;
        border-color: #050a0e;
        border-width: 1px;
        border-radius: 5px;
        color: #d3dae3;
        padding: 2px;
        background-color: rgba(28, 31, 31,50);
}
QPushButton:pressed{
        border-style: solid;
        border-color: #050a0e;
        border-width: 1px;
        border-radius: 5px;
        color: #d3dae3;
        padding: 2px;
        background-color: rgba(44, 47, 47,50);
})--");
}

login::~login()
{
    delete ui;
}

void login::on_loginButton_clicked()
{
    QString phone, password;
    phone = ui->phoneEdit->text();
    password = ui->passwordEdit->text();
    emit loginSignal(phone, password);

}

void login::loginResult(bool state)
{
    if (state) {
        ui->stackedWidget->setCurrentIndex(1);
    } else {
        ui->loginStateLabel->setText("登录失败");
    }
}


void login::on_logoutButton_clicked()
{
    emit logoutSignal();
    ui->loginStateLabel->clear();
    ui->stackedWidget->setCurrentIndex(0);
}

