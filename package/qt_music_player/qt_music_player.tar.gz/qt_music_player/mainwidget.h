#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
//#include "musicwidget.h"
#include "musiclist.h"
#include <QMediaPlayer>
#include "network.h"
#include "playlist.h"
#include "login.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWidget; }
QT_END_NAMESPACE

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    MainWidget(QWidget *parent = nullptr);
    ~MainWidget();
public slots:
    void maxRestore();
    void playSlot();
    void stopSlot();
    void startPlay(int n);

private slots:
    void on_musicButton_clicked();
   // void addSongs(QList<QUrl> *url);

    void on_searchEdit_returnPressed();

    // void on_searchTable_itemDoubleClicked(QTableWidgetItem *item);

    void on_searchTable_cellDoubleClicked(int row, int column);


    //void loginRequestSlot(QString phone, QString password);
    void logoutRequestSlot();

    void on_loginButton_clicked();

private:
    Ui::MainWidget *ui;
    //MusicWidget *mw;
    MusicList *musicList;
    QMediaPlayer *player;
    PlayList *playList;
    Network *network;
    login *m_login;
    enum class PlayState {
        playing,
        stop
    };
    PlayState playState = PlayState::stop;
    QMediaPlaylist::PlaybackMode playMode;

virtual void paintEvent(QPaintEvent *ev)override;
void initUI();
virtual void mousePressEvent(QMouseEvent *ev)override;
QPoint movePoint;
virtual void mouseMoveEvent(QMouseEvent *ev)override;
virtual void closeEvent(QCloseEvent *ev)override;
virtual void resizeEvent(QResizeEvent *ev)override;

};
#endif // MAINWIDGET_H
