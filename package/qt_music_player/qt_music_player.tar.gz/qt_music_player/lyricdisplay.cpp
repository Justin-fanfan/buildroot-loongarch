#include "lyricdisplay.h"
#include <QTextStream>
#include <QRegExp>
#include <QDebug>
#include <QFrame>
#include <QScrollBar>
#include<QHBoxLayout>
#include <QPropertyAnimation>

LyricDisplay::LyricDisplay(QWidget *parent):
    QScrollArea(parent)
{
     scrollContent = new QWidget(this);
     scrollContent->setGeometry(0,0,2000,3000);



    widget = new QFrame(scrollContent);

    // widget->setFrameStyle(QFrame::Box);
     widget->setFrameStyle(QFrame::NoFrame);
    layout = new QVBoxLayout(widget);
    // widget->setLayout(layout);
    this->setWidget(scrollContent);
    //this->setHorizontalScrollBar(new QScrollBar());
    horizontalScrollBar()->setStyleSheet("QScrollBar {height:0px;}");
     scrollContent->setStyleSheet("background-color:rgba(0,0,0,0)");
     this->setStyleSheet("background-color:rgba(0,0,0,0)");
    this->setFrameStyle(QFrame::NoFrame);


}

static void printLyric(Lyric lyric) {
    for (int i = 0; i < lyric.size(); i++) {
        qDebug()<<"["<<(double)lyric[i].milisec/1000<<"]"<<lyric[i].line;
    }
}

static QPalette originPalette;

bool LyricDisplay::setLyric(const QString &rawLyric)
{
    if (labelVector.size() > 0) {
        clearLabels();
    }
    QString str = rawLyric;
    QTextStream *textStream = new QTextStream(&str, QIODevice::ReadOnly);
    while (!textStream->atEnd()) {
        QString line = textStream->readLine();
        LyricLine lyricLine;
        QRegExp rx(R"--(\[(\d\d):(\d\d.\d\d\d?)\](.*))--");
        if (rx.indexIn(line) >= 0) {
            lyricLine.milisec = rx.cap(1).toInt() * 60000 + static_cast<int>(rx.cap(2).toFloat()*1000);
            lyricLine.line = rx.cap(3);
            lyric.append(lyricLine);
        } else {
            qDebug() << "invalid lyric";
            return false;
        }


    }
        for (int i = 0; i < lyric.size(); i++) {
            auto l = new QLabel(lyric[i].line, widget);
            l->setTextInteractionFlags(Qt::TextSelectableByMouse);
            l->setAlignment(Qt::AlignTop|Qt::AlignHCenter);
            l->setMaximumHeight(25);
            l->setMinimumHeight(25);
            l->setMinimumWidth(500);
            layout->addWidget(l);
             // l->setFrameStyle(QFrame::Box);
            labelVector.push_back(l);

        }

        widget->adjustSize();
        widget->resize(widget->width(), 35 * labelVector.size());
        widget->move(this->width() / 2 - widget->width()/ 2,0);
        //auto w = new QFrame(scrollContent);
        scrollContent->setGeometry(0,0, 2000, widget->height() + this->height() / 2);
        this->verticalScrollBar()->setValue(0);
        //w->setGeometry(widget->x(),widget->height(),widget->width(), widget->height());
        // verticalScrollBar()->setMaximum(400);
        currentLine = -1;
       // printLyric(lyric);
        if (labelVector.size() > 0) {
            originPalette = labelVector[0]->palette();
        }

    delete textStream;
    return true;
}

void LyricDisplay::showGeometry() {
    qDebug() << widget->geometry();
}

void LyricDisplay::clearLabels() {
    for (int i = 0; i < labelVector.size(); i++) {
        labelVector[i]->deleteLater();
    }
    labelVector.clear();
    lyric.clear();
}

void LyricDisplay::goToLine(int n)
{
    if (currentLine == n || n < 0)
        return ;
    if (n >= labelVector.size()) {
        qDebug() << "error: LyricDisplay::goToLine";
        return ;
    }
    if (currentLine != -1)
        labelVector[currentLine]->setStyleSheet("color:#d3dae3");
    labelVector[n]->setStyleSheet("color:red");
    int dis = this->height() / 2 - (scrollContent->y() +  widget->y() + labelVector[n]->y() + labelVector[n]->height() / 2);
    QPropertyAnimation *anni = new QPropertyAnimation(verticalScrollBar(), "value");
    anni->setStartValue(verticalScrollBar()->value());
    anni->setEndValue(verticalScrollBar()->value() - dis);
    anni->setDuration(500);
    anni->start();
        // qDebug() << labelVector[0]->font();
        // qDebug() << labelVector[0]->geometry();
        // qDebug() << layout->contentsMargins();
     // verticalScrollBar()->setValue(verticalScrollBar()->value() - dis);
    currentLine = n;
}

void LyricDisplay::setPosition(int time)
{
    /*寻找最后一个时间<=time的歌词，二分查找
     */
    time += 200;
    int left = 0, right = lyric.size() - 1;
    int mid = -1;
    while (left < right) {
         mid = (right + left + 1) / 2;
         // qDebug() << mid << ":" << lyric[mid].milisec;
        if (lyric[mid].milisec > time) {
            right = mid - 1;
        } else {
            left = mid;
        }
    }
    if (right != left || lyric[left].milisec > time) {
        left = -1;
    }
    goToLine(left);


}

void LyricDisplay::resizeEvent(QResizeEvent *ev)
{
    Q_UNUSED(ev);
    widget->move(this->width() / 2 - widget->width()/ 2,0);
}
