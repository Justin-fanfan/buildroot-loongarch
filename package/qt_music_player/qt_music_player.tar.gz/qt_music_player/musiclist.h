#ifndef MUSICLIST_H
#define MUSICLIST_H

#include <QWidget>
#include <QFile>
#include <QTextStream>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <QUrl>
#include "playlist.h"
#include "subwindow.h"

namespace Ui {
class MusicList;
}

class MusicList : public SubWindow
{
    Q_OBJECT

public:
    explicit MusicList();
    ~MusicList();
    PlayList* getPlayList();

private slots:
    void on_addButton_clicked();

    void on_musicTable_doubleClicked(const QModelIndex &index);

    void on_delButton_clicked();

    void on_clearButton_clicked();

private:
    Ui::MusicList *ui;
    QFile musicFile;
    QList<QUrl> *urls;
    PlayList *playList;
signals:
    void addSongs(QList<QUrl> *urls);
    void musicListDoubleClicked(int n);
};

#endif // MUSICLIST_H
