#include "musiclist.h"
#include "ui_musiclist.h"
#include "QFileDialog"
#include "QListIterator"
#include <QMediaMetaData>
#include <QScrollBar>
MusicList::MusicList() :
    SubWindow(nullptr),
    ui(new Ui::MusicList)
{
    ui->setupUi(this);
    playList = new PlayList(ui->musicTable, this);
    urls = new QList<QUrl>;
    ui->musicTable->setRowCount(0);
    // ui->musicTable->setColumnCount(3);
     ui->musicTable->setHorizontalHeaderItem(0, new QTableWidgetItem("歌名"));
     ui->musicTable->setHorizontalHeaderItem(1, new QTableWidgetItem("歌手"));
    // ui->musicTable->setHorizontalHeaderItem(2, new QTableWidgetItem("时间"));
    // musicFile.setFileName("music.txt");
    // if (!musicFile.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        // return ;
    // }
     setStyleSheet(R"--(
QPushButton{
        border-style: solid;
        border-color: #a8dadc;
        border-width: 1px;
        border-radius: 5px;
        color: rgb(0,0,0);
        padding: 2px;
        background-color: #a8dadc;
}
QPushButton::default{
        border-style: solid;
        border-color: #050a0e;
        border-width: 1px;
        border-radius: 5px;
        color: #FFFFFF;
        padding: 2px;
        background-color: #151a1e;;
}
QPushButton:hover{
        border-style: solid;
        border-color: #050a0e;
        border-width: 1px;
        border-radius: 5px;
        color: #d3dae3;
        padding: 2px;
        background-color: #1c1f1f;
}
QPushButton:pressed{
        border-style: solid;
        border-color: #050a0e;
        border-width: 1px;
        border-radius: 5px;
        color: #d3dae3;
        padding: 2px;
        background-color: #2c2f2f;
}
)--");
    ui->musicTable->verticalScrollBar()->setStyleSheet(R"--(
QScrollBar:vertical {
        max-width: 10px;
        border: 1px transparent grey;
        margin: 20px 0px 20px 0px;
        background: transparent;
}
QScrollBar::handle:horizontal {
        background: #52595d;
        border-style: transparent;
        border-radius: 4px;
        min-width: 25px;
}
QScrollBar::handle:horizontal:hover {
        background: #58a492;
        border-style: transparent;
        border-radius: 4px;
        min-width: 25px;
}
QScrollBar::handle:vertical {
        background: #52595d;
        border-style: transparent;
        border-radius: 4px;
        min-height: 25px;
}
QScrollBar::handle:vertical:hover {
        background: #58a492;
        border-style: transparent;
        border-radius: 4px;
        min-height: 25px;
}
QScrollBar::add-line:horizontal {
   border: 2px transparent grey;
   border-top-right-radius: 4px;
   border-bottom-right-radius: 4px;
   background: #15433a;
   width: 20px;
   subcontrol-position: right;
   subcontrol-origin: margin;
}
QScrollBar::add-line:horizontal:pressed {
   border: 2px transparent grey;
   border-top-right-radius: 4px;
   border-bottom-right-radius: 4px;
   background: rgb(181,181,181);
   width: 20px;
   subcontrol-position: right;
   subcontrol-origin: margin;
}
QScrollBar::add-line:vertical {
   border: 2px transparent grey;
   border-bottom-left-radius: 4px;
   border-bottom-right-radius: 4px;
   background: #15433a;
   height: 20px;
   subcontrol-position: bottom;
   subcontrol-origin: margin;
}
QScrollBar::add-line:vertical:pressed {
   border: 2px transparent grey;
   border-bottom-left-radius: 4px;
   border-bottom-right-radius: 4px;
   background: rgb(181,181,181);
   height: 20px;
   subcontrol-position: bottom;
   subcontrol-origin: margin;
}
QScrollBar::sub-line:horizontal {
   border: 2px transparent grey;
   border-top-left-radius: 4px;
   border-bottom-left-radius: 4px;
   background: #15433a;
   width: 20px;
   subcontrol-position: left;
   subcontrol-origin: margin;
}
QScrollBar::sub-line:horizontal:pressed {
   border: 2px transparent grey;
   border-top-left-radius: 4px;
   border-bottom-left-radius: 4px;
   background: rgb(181,181,181);
   width: 20px;
   subcontrol-position: left;
   subcontrol-origin: margin;
}
QScrollBar::sub-line:vertical {
   border: 2px transparent grey;
   border-top-left-radius: 4px;
   border-top-right-radius: 4px;
   background: #15433a;
   height: 20px;
   subcontrol-position: top;
   subcontrol-origin: margin;
}
QScrollBar::sub-line:vertical:pressed {
   border: 2px transparent grey;
   border-top-left-radius: 4px;
   border-top-right-radius: 4px;
   background: rgb(181,181,181);
   height: 20px;
   subcontrol-position: top;
   subcontrol-origin: margin;
}

QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
   background: none;
}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
   background: none;
}



)--");
}


MusicList::~MusicList()
{
    delete urls;
    delete ui;
}

PlayList *MusicList::getPlayList()
{
    return playList;
}

void MusicList::on_addButton_clicked()
{
    auto path = QFileDialog::getOpenFileNames(this,
                                  "读取.mp3文件","/", "(*.mp3)");
    if (!path.isEmpty()) {
        for (auto &p : path) {
            auto url = QUrl::fromLocalFile(p);
            playList->append(Song(url));
            // urls->append(url);
            // playList->addMedia(url);
            // t.setMedia(url);
            // QString title = t.metaData(QMediaMetaData::Title).toString();
            // if (title.isEmpty()) {
                // title = t.metaData(QMediaMetaData::AlbumTitle).toString();
            // }
            // QString name = t.metaData(QMediaMetaData::Author).toString();
            // if (name.isEmpty()) {
                // name = t.metaData(QMediaMetaData::AlbumArtist).toString();
            // }
            // int nRow = ui->musicTable->rowCount();
            // ui->musicTable->insertRow(nRow);
            // if (!title.isEmpty()) {
                // ui->musicTable->setItem(nRow, 0, new QTableWidgetItem(title));
            // } else {
                // ui->musicTable->setItem(nRow, 0, new QTableWidgetItem("未知"));
            // }
            // if (!name.isEmpty()) {
                // ui->musicTable->setItem(nRow, 1, new QTableWidgetItem(name));
            // } else {
                // ui->musicTable->setItem(nRow, 1, new QTableWidgetItem("未知"));
            // }
        }
        // QListIterator<QString> addMusicList(path);
        // while (addMusicList.hasNext()) {
            // auto addSongs = addMusicList.next();
            // QTextStream stream(&musicFile);
            // stream << addSongs << "\n";
        // }
    }
    // musicFile.close();
}


void MusicList::on_musicTable_doubleClicked(const QModelIndex &index)
{
   // qDebug() << index.row();
    emit musicListDoubleClicked(index.row());
}

void MusicList::on_delButton_clicked()
{
    int row = ui->musicTable->currentIndex().row();
    int curPlay = playList->currentIndex();
    playList->deleteByIndex(row);


}


void MusicList::on_clearButton_clicked()
{
    playList->clearList();
}

