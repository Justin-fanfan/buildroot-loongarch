#ifndef SUBWINDOW_H
#define SUBWINDOW_H
#include <QWidget>
#include <QPushButton>


class SubWindow : public QWidget
{
    Q_OBJECT
public:
    explicit SubWindow(QWidget *parent = nullptr);
private:
    QPushButton *closeButton;
protected:
    virtual void paintEvent(QPaintEvent *event)override;
    virtual void mousePressEvent(QMouseEvent *event)override;
    virtual void mouseMoveEvent(QMouseEvent *event)override;
signals:

};

#endif // SUBWINDOW_H
