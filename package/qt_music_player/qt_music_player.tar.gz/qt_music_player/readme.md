# QT音乐播放器

## 简介

这是一款使用C++ QT编写的在线音乐播放器，可以运行在Windows/Linux/Mac平台上。音乐播放器使用网易云API(非官方API)实现歌曲在线搜索和网易云音乐登录。登录网易云账号后可播放自己歌单中的歌曲。

项目中使用的网易云音乐API为 [Binaryify/NeteaseCloudMusicApi](https://binaryify.github.io/NeteaseCloudMusicApi)。使用该API需要自行搭建后端服务器，可参考[NeteaseCloudMusicApi](https://github.com/Binaryify/NeteaseCloudMusicApi)  或者使用在线服务器https://163.lpddr5.cn/

项目使用的QT版本为QT 5.14

音乐播放器界面:

![](https://images.gitee.com/uploads/images/2021/1026/160602_42106b15_1339030.png "show1.PNG")

![](https://images.gitee.com/uploads/images/2021/1026/160617_ce88fba7_1339030.png "show2.PNG")
## 主要功能

- #### 无边框窗口

  ​	主界面使用无边框窗口，实现了窗口的拖拽和拉伸。

- #### 音乐播放器的基本功能，播放，暂停，音量调节，上/下一曲，切换播放模式(单曲循环，列表循环等)

- #### 本地音乐播放

  ​	可以添加本地音乐到歌单并播放

- #### 在线音乐搜索

  ​	通过关键词可搜索歌曲,关键词会匹配音乐标题，歌手，和专辑名。双击歌曲可以播放搜索到的歌曲。搜索功能使用了网易云音乐的接口，可以不登录账号使用。

- #### 歌词显示，歌词随歌曲进度同步滚动

  ​	播放歌曲时，如果歌曲是在线歌曲，播放器会通过网易云音乐API请求歌词并解析歌词文件。点击歌词按钮可以显示歌曲的歌词，歌词会随歌曲的进度同步滚动。

- #### 网易云音乐账号登录

  ​	通过手机号和密码可以登录网易云音乐账号。登录账号后可显示自己的歌单并播放歌单中的歌曲，在左侧列表点击对应歌单后能显示歌单中的歌曲列表.

- #### 播放列表窗口

  ​	点击播放列表按就可以打开播放列表，可以在播放列表中切换歌曲，删除歌曲，添加本地歌曲到播放列表。



## 代码结构和接口说明

#### 主界面MainWidget类

mainwidget.cpp,mainwidget,mainwidget.ui

主窗口`MainWidegt`类继承自`QWidet` ，用于创建音乐播放器主窗口，显示界面元素，响应用户操作，控制歌曲播放，通过信号与槽机制向其它对象发送消息，接收其他对象的信号并处理。

#### 自定义窗口基类SubWindow

文件: subwindow.cpp,subwindow.h 

继承自`QWidget`, 无边框(FramelessWindowHint)，带有关闭按钮，支持鼠标拖拽移动的窗口



#### 登录窗口Login

login.cpp,login.h,login.ui

继承自`SubWindow`, 用于创建登录窗口，向主窗口发送登录和注销的信号。

登录界面:

<img src="https://images.gitee.com/uploads/images/2021/1026/160449_2fd0cafb_1339030.png" style="zoom: 50%;" />

#### 播放列表窗口MusicList

musiclist.cpp,musiclist.h,musiclist.ui

播放窗口类,继承自`SubWindow`, 用于创建播放列表窗口。 

#### 歌曲信息Song，SongList类

Song.h

`Song`类定义了一首歌曲的基本信息，如歌名`songName`, 歌手名`artistName`,

歌曲在网络或本地的地址`url`等。

`SongList`类继承自`QList<Song>`

**接口:**

`void wirteToTable(QTableWidget *tb);` 用SongList中的歌曲信息替换表格tb的内容

`void appendToTable(QTableWidget *tb);`将SongList里的歌曲添加到表格tb尾部。

#### 网络请求 Network类

network.cpp, network.h

处理登录，注销，歌曲搜索，歌曲url获取等网络请求

**接口:**

 `void search(QString keywords, int limit = 30, int offset = 0);`
 以keywords为关键字搜索歌曲，limit指定查询结果中每页最大歌曲数量，offset指定返回第几页查询结果

`void getSongUrl(Song song);`通过song获取歌曲的URL地址
`void getLyric(unsigned id);`通过歌曲id获取歌词
`void getPlayListById(unsigned id);`通过歌单id获取该用户歌单中的所有歌曲
`void logout();`注销当前登录的用户

以上网络请求会以发送信号的方式返回结果。

比如search请求得到响应报文并解析完毕后会发出`void searchDone(SongList) `信号告诉调用者搜索结果

#### 播放列表PlayList类

playlist.h,playlist.cpp

继承自`QMediaPlaylist`,维护音乐播放器的当且播放列表

**接口:**

`void append(Song song);`向播放列表添加歌曲song

`void appendAndPlay(Song song); `添加歌曲并播放
`void appendSongList(const SongList &list);`添加一个SongList
`    void deleteByIndex(int n); `删除列表中第n+1首歌曲
` void clearList(); `清空播放列表
`void loadList(const SongList &list);`情况当且列表并从list加载播放列表
` void saveInFile(QString path);`将播放列表保存到path指定的本地文件

#### 歌词显示LyricDisplay类

lyricdisplay.cpp,lyricdisplay.h

继承自`QScrollArea`,用于显示歌词

**接口:**

`bool setLyric(const QString  &rawLyric)`使用未解析的歌词字符串`rawLyric`作为当且歌曲的歌词。LyricDisplay会根据歌曲的进度同步滚动歌词。

`public slot:`

`void setPosition(int time)` 使用该函数通知LyricDisplay当且歌曲的进度，time的单位为毫秒。

#### SongTable

songtable.cpp,songtable.h

继承自`QTableWidget`,用于歌曲列表的显示。设置了表格的样式，音乐播放器中显示的所有歌曲列表都是`SongTable`类。

####  主函数

main.cpp

创建`MainWidget`窗口并进入消息循环。

#### 图标和qss资源

/pic文件夹下存放了音乐播放器用到的图片资源

styleSheet.qss为qt样式表文件



