#include "songtable.h"
#include <QHeaderView>

SongTable::SongTable(QWidget *parent) : QTableWidget(parent)
{
    setSelectionBehavior(QAbstractItemView::SelectRows);
    horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    setFrameShape(QFrame::NoFrame);
    setShowGrid(false);
    verticalHeader()->hide();
    setEditTriggers(QAbstractItemView::NoEditTriggers);
    setStyleSheet(R"--(
QTableWidget{border:none;border:0px;background-color: rgba(219, 255, 171, 0);outline:0px}
QTableWidget::item{background-color: rgba(0, 0, 0, 0);color:#ffffff;}
QTableWidget::item:hover{background-color: rgba(151, 212, 205, 100);color:#000000;}
QTableWidget::item:selected{background-color: rgba(151, 212, 205, 100);color:#000000;}
)--");
    setColumnCount(2);
    setHorizontalHeaderLabels({"歌名","歌手"});

}
