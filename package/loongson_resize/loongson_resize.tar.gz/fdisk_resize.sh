#! /bin/sh

run_dir="/usr/local/ls_resize/"
fstab_path="/etc/fstab"
fstab_bak_path="/etc/fstab-ori"

handle_dev="/dev/mmcblk0"
disk_size=0
disk_size_MB=0

root_partition_size=0
root_partition_size_MB=0
root_partition_only=1

data_partition_need=0
data_partition_num=2
data_partition=$handle_dev"p"$data_partition_num
data_partition_size=0
data_partition_size_MB=0
data_partition_size_txt="+2G"

data_partition_mount_path="/mnt"

swap_partition_need=0
swap_partition_num=3
swap_partition=$handle_dev"p"$swap_partition_num
swap_partition_size=0
swap_partition_size_MB=0
swap_partition_size_txt="+1G"

backup_partition_need=0
backup_partition_num=4
backup_partition=$handle_dev"p"$backup_partition_num
backup_partition_size=0
backup_partition_size_MB=0
backup_partition_size_txt=""

ROOTDEV_P=`cat /proc/cmdline  | sed 's/ /\n/g' | grep root= | cut -d = -f 2 | head -n1`
ROOTDEV="/dev/"
PARTNUM=1

read_disk_size()
{
	GB_display=0
	disk_size=$(fdisk -l | grep "Disk $handle_dev" | head -n1 | cut -d ' ' -f3 | cut -d '.' -f1);
	fdisk -l | grep "Disk $handle_dev" | head -n1 | grep GiB >/dev/null
	if [ $? -eq 1 ]; then
		fdisk -l | grep "Disk" | head -n1 | grep GB >/dev/null
		if [ $? -eq 0 ]; then
			GB_display=1
		fi
	else
		GB_display=1
	fi
	# if just MB size
	if [ $GB_display -eq 0 ]; then
		disk_size_MB=$(($disk_size/1024))
	else
		disk_size_MB=$(($disk_size*1024))
	fi
}

analy_swap_size()
{
	mem_size=$(cat /proc/meminfo | grep MemTotal | head -n1 | tr -s ' ' | cut -d ' ' -f 2)

	if [ $mem_size -le 1048576 ]; then
		# 1024MB
		swap_partition_size=1
		swap_partition_size_MB=1024
		swap_partition_size_txt="+1G"
	else
		# 1024MB
		swap_partition_size=2
		swap_partition_size_MB=2048
		swap_partition_size_txt="+2G"
	fi
}

#$1 是第一个的比例
#$2 是第二个的比例
#$3 瓜分总数
buffer_num1=0;
buffer_num2=0;
spilt_num_to_buffer()
{
	buffer_num1=0
	buffer_num2=0
	count=$(($1+$2))
	total_num=$3

	if [ $1 -le 0 ]; then
		buffer_num2=$3
		return 0
	elif [ $2 -le 0 ]; then
		buffer_num1=$3
		return 0
	fi

	while [ $total_num -ge $count ]
	do
		buffer_num1=$(($buffer_num1+$1))
		buffer_num2=$(($buffer_num2+$2))
		total_num=$(($total_num-$count))
	done
	if [ $1 -lt $2 ]; then
		buffer_num2=$(($buffer_num2+$total_num))
	else
		buffer_num1=$(($buffer_num1+$total_num))
	fi
}

split_rootdata_and_backup()
{
	spilt_num_to_buffer $1 $2 $3
	disk_size_root_and_data=$buffer_num1
	disk_size_backup=$buffer_num2

}

split_root_and_data()
{
	spilt_num_to_buffer $1 $2 $3
	disk_size_root=$buffer_num1
	disk_size_data=$buffer_num2
}

fdisk_data_part()
{
	fdisk $handle_dev &>/dev/null << !
n
p
$data_partition_num

$data_partition_size_txt


w
!
}

fdisk_swap_part()
{
	fdisk $handle_dev &>/dev/null << !
n
p
$swap_partition_num

$swap_partition_size_txt


t
$swap_partition_num
82

w
!
}

fdisk_backup_part()
{
	fdisk $handle_dev &>/dev/null << !
n
p
$backup_partition_num

$backup_partition_size_txt


w
!
}

analy_part_type()
{
	handle_dev="/dev/sda"
	data_partition=$handle_dev$data_partition_num
	swap_partition=$handle_dev$swap_partition_num
	backup_partition=$handle_dev$backup_partition_num
	if [[ $ROOTDEV_P == /dev/mmcblk0* ]]; then
		handle_dev="/dev/mmcblk0"
		data_partition=$handle_dev"p"$data_partition_num
		swap_partition=$handle_dev"p"$swap_partition_num
		backup_partition=$handle_dev"p"$backup_partition_num
		PARTNUM=$(echo $ROOTDEV_P | cut -d p -f 2)
	elif [[ $ROOTDEV_P == /dev/sdb* ]]; then
		handle_dev="/dev/sdb"
	elif [[ $ROOTDEV_P == /dev/mmcblk1* ]]; then
		handle_dev="/dev/mmcblk1"
		data_partition=$handle_dev"p"$data_partition_num
		swap_partition=$handle_dev"p"$swap_partition_num
		backup_partition=$handle_dev"p"$backup_partition_num
		PARTNUM=$(echo $ROOTDEV_P | cut -d p -f 2)
	fi
}

#分析4分区，包括乒乓系统
analy_twosys()
{
	if [ $disk_size -le 8 ]; then
		root_partition_size=2
		root_partition_size_MB=$(($root_partition_size * 1024))

		data_partition_size=2
		data_partition_size_MB=2048
		data_partition_size_txt="+2G"

		if [ $swap_partition_size -eq 2 ]; then
			swap_partition_size=1
			swap_partition_size_MB=1024
			swap_partition_size_txt="+1G"
		fi

		backup_partition_size=0
		backup_partition_size_txt=""
	elif [ $disk_size -le 16 ]; then
		root_partition_size=4
		root_partition_size_MB=$(($root_partition_size * 1024))

		data_partition_size=5
		data_partition_size_MB=5120
		data_partition_size_txt="+5G"

		backup_partition_size=0
		backup_partition_size_MB=0
		backup_partition_size_txt=""
	else
		#/2会向下取整，也就是backup的大小 >= root+data
		disk_size_root_and_data=$(($disk_size-$swap_partition_size))
		disk_size_root_and_data=$(($disk_size_root_and_data/2))
		split_root_and_data 1 2 $disk_size_root_and_data;
		root_partition_size=$buffer_num1
		root_partition_size_MB=$(($buffer_num1*1024))

		data_partition_size=$buffer_num2
		data_partition_size_MB=$(($buffer_num2*1024))
		data_partition_size_txt="+""$buffer_num2""G"

		backup_partition_size=0
		backup_partition_size_MB=0
		backup_partition_size_txt=""
	fi
}

#分析4分区，包括乒乓系统
analy_twosys_3()
{
	if [ $disk_size -le 8 ]; then
		root_partition_size=4
		root_partition_size_MB=$(($root_partition_size * 1024))

		if [ $swap_partition_size -eq 2 ]; then
			swap_partition_size=1
			swap_partition_size_MB=1024
			swap_partition_size_txt="+1G"
		fi

		backup_partition_size=0
		backup_partition_size_txt=""
	elif [ $disk_size -le 16 ]; then
		root_partition_size=8
		root_partition_size_MB=$(($root_partition_size * 1024))

		backup_partition_size=0
		backup_partition_size_MB=0
		backup_partition_size_txt=""
	else
		#/2会向下取整，也就是backup的大小 >= root+data
		disk_size_root_and_data=$(($disk_size-$swap_partition_size))
		disk_size_root_and_data=$(($disk_size_root_and_data/2))
		root_partition_size=$disk_size_root_and_data
		root_partition_size_MB=$(($root_partition_size * 1024))

		backup_partition_size=0
		backup_partition_size_MB=0
		backup_partition_size_txt=""
	fi
}

analy_part_info()
{
	fdisk_txt_context=""
	if [ -f "fdisk.txt" ]; then
		fdisk_txt_context=$(cat fdisk.txt | head -n1)
		if [ ! -z $fdisk_txt_context ]; then
			touch ./$fdisk_txt_context
		fi
	fi

	if [ -f "twosys" ]; then
		root_partition_only=0
		data_partition_need=1
		swap_partition_need=1
		backup_partition_need=1
		analy_twosys
	elif [ -f "twosys_3" ]; then
		root_partition_only=0
		data_partition_need=0
		swap_partition_need=1
		backup_partition_need=1
		analy_twosys_3
	fi

	if [ ! -z $fdisk_txt_context ]; then
		rm -rf ./$fdisk_txt_context
	fi

	analy_part_info_debug=0
	if [ $analy_part_info_debug -eq 1 ]; then
		echo ""
		echo "$root_partition_size"
		echo "$root_partition_size_MB"
		echo "$root_partition_only"

		echo ""
		echo "$data_partition_need"
		echo "$data_partition_num"
		echo "$data_partition"
		echo "$data_partition_size"
		echo "$data_partition_size_MB"
		echo "$data_partition_size_txt"

		echo ""
		echo "$swap_partition_need"
		echo "$swap_partition_num"
		echo "$swap_partition"
		echo "$swap_partition_size"
		echo "$swap_partition_size_MB"
		echo "$swap_partition_size_txt"

		echo ""
		echo "$backup_partition_need"
		echo "$backup_partition_num"
		echo "$backup_partition"
		echo "$backup_partition_size"
		echo "$backup_partition_size_MB"
		echo "$backup_partition_size_txt"
	fi
}

parted_root_part()
{
	ret=0
	if [ $root_partition_only -eq 0 ]; then
		parted $handle_dev --script -- resizepart $PARTNUM $root_partition_size_MB
		ret=$?
	else
		parted $handle_dev --script -- resizepart $PARTNUM -0
		ret=$?
	fi
	if [ $ret -ne 0 ]; then
		exit 1
	fi
	resize2fs $ROOTDEV_P
	if [ $? -ne 0 ]; then
		exit 1
	fi
}

fdisk_other_part()
{
	if [ $root_partition_only -eq 1 ]; then
		return 0
	fi

	if [ $data_partition_need -eq 1 ]; then
		echo "data fdisk start"
		fdisk_data_part
	fi
	if [ $swap_partition_need -eq 1 ]; then
		echo "swap fdisk start"
		fdisk_swap_part
	fi
	if [ $backup_partition_need -eq 1 ]; then
		echo "backup fdisk start"
		fdisk_backup_part
	fi
}

mkfs_other_part()
{
	if [ $root_partition_only -eq 1 ]; then
		return 0
	fi

	if [ -e $data_partition ]; then
		mke2fs -t ext4 -L data -F $data_partition >/dev/null;
		sync
	fi

	if [ -e $swap_partition ]; then
		mkswap $swap_partition >/dev/null;
		sync
	fi

	if [ -e $backup_partition ]; then
		mke2fs -t ext4 -L rootfs -F $backup_partition -O ^metadata_csum >/dev/null;
		sync
	fi
}

gen_fstab()
{
	if [ ! -f $fstab_bak_path ]; then
		cp $fstab_path $fstab_bak_path
	fi

	rm $fstab_path
	echo "$ROOTDEV_P			/ 		ext4 		rw,relatime,data=ordered 0 1" >> $fstab_path

	if [ -e $data_partition ]; then
		echo "$data_partition			/data		ext4		rw,relatime,data=ordered 0 1" >> $fstab_path
	fi

	if [ -e $swap_partition ]; then
		echo "$swap_partition			none		swap		defaults,pri=-2 0 0" >> $fstab_path
	fi

	if [ -e $data_partition ]; then
		echo "" >> $fstab_path
		echo "/data/root			/root		none		defaults,bind 0 0" >> $fstab_path
		echo "/data/home			/home		none		defaults,bind 0 0" >> $fstab_path
		echo "/data/opt			/opt		none		defaults,bind 0 0" >> $fstab_path
		echo "/data/var			/var		none		defaults,bind 0 0" >> $fstab_path
	fi

	echo "" >> $fstab_path
	echo "proc			/proc		proc		defaults,nodev,nosuid 0 0" >> $fstab_path
	echo "sysfs			/sys		sysfs		defaults,nodev,nosuid 0 0" >> $fstab_path
}

data_partition_init()
{
	if [ ! -e $data_partition ]; then
		return 0
	fi

	mkdir -p $data_partition_mount_path
	mount $data_partition $data_partition_mount_path
	if [ -d /home ]; then
		mv /home $data_partition_mount_path/
	fi
	if [ -d /root ]; then
		mv /root $data_partition_mount_path/
	fi
	if [ -d /opt ]; then
		mv /opt $data_partition_mount_path/
	fi
	if [ -d /var ]; then
		mv /var $data_partition_mount_path/
	fi
	if [ -d /data ]; then
		mv /data/* $data_partition_mount_path/
	fi

	rm -rf /data
	mkdir -p /data
	mkdir -p /home
	mkdir -p /root
	mkdir -p /opt
	mkdir -p /var
}

old_path=$PWD
cd $run_dir

echo "analy_part_type"
analy_part_type
echo "read_disk_size"
read_disk_size
echo "analy_swap_size"
analy_swap_size
echo "analy_part_info"
analy_part_info
echo "parted_root_part"
parted_root_part
echo "fdisk_other_part"
fdisk_other_part
echo "mkfs_other_part"
mkfs_other_part
echo "gen_fstab"
gen_fstab
echo "data_partition_init"
data_partition_init

if [ $root_partition_only -eq 0 ]; then
	mount -a
fi

cd $old_path
